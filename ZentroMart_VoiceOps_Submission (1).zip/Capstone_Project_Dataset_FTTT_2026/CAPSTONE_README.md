# ZentroMart VoiceOps Capstone

A synthetic-data customer-support assistant with policy-aware retrieval,
catalog lookup, evidence IDs, and a Gnani-only speech pipeline.

## Project structure

- `run.py` — command-line interface
- `src/answer_engine.py` — grounded answer routing
- `src/retriever.py` — Markdown policy retrieval
- `src/kb_parser.py` — policy metadata and section parser
- `src/catalog.py` — product catalog lookup
- `src/data_loader.py` — loads the local catalog and knowledge base
- `src/speech.py` — Gnani STT → answer engine → Gnani TTS
- `data/` — synthetic catalog, order and customer data
- `kb/` — policy and help documents
- `sample_outputs/` — generated test outputs

## Install

Use Python 3.10 or newer in a virtual environment:

```bash
pip install -r requirements.txt
```

## Configure Gnani

Copy `.env.example` to `.env` and replace the placeholder with your
authorized Gnani API key. Never commit `.env` or share the key.

## Ask a text question

```bash
python run.py --question "What is the return window for electronics and accessories?"
```

For structured output:

```bash
python run.py --question "What is the price of ELE-0001?" --json
```

## Process a recorded voice question

Record a short question in a supported audio format and save it as
`sample_outputs/customer_question.wav`. Then run this from the project root:

```bash
python -c "from src.speech import process_audio; print(process_audio('sample_outputs/customer_question.wav'))"
```

The speech pipeline saves a transcript, reply text, result JSON and reply WAV
in `sample_outputs/`. It requires a valid Gnani key and a working SDK account.

## Privacy and safety

- The supplied dataset is synthetic.
- Never put API keys in source files or commit `.env`.
- Order-specific actions must use the supplied verification and escalation
  tools; do not expose order details before verification.
- Unsupported questions should be handed to support rather than answered
  by guessing.

## Current limitations

The current answer engine covers selected policy and catalog scenarios.
It is not yet a complete replacement for every baseline chatbot intent.
Run the evaluation suite and inspect evidence IDs before claiming full
benchmark accuracy. A real voice demo requires a valid Gnani account and
an actual recorded test clip.
