"""Command-line entry point for ZentroMart VoiceOps."""

import argparse
import json
import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from src.answer_engine import answer_customer_question


def main():
    parser = argparse.ArgumentParser(
        description="Ask the ZentroMart customer-support assistant."
    )
    parser.add_argument(
        "--question",
        type=str,
        help="Customer question to answer."
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print the complete structured response as JSON."
    )
    args = parser.parse_args()

    if not args.question or not args.question.strip():
        parser.error("Provide a question with --question.")

    result = answer_customer_question(args.question)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("Answer:", result["answer"])
        print("Status:", result["status"])
        if result.get("evidence_ids"):
            print("Evidence:", ", ".join(result["evidence_ids"]))

    return 0 if result["status"] in ("answered", "needs_review") else 1


if __name__ == "__main__":
    raise SystemExit(main())
